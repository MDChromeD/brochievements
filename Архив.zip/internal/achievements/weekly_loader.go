package achievements

import (
	"brochievements/internal/storage"
	"time"
)

func lastWeekRange() (from, to time.Time) {
	now := time.Now()
	to = time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	from = to.AddDate(0, 0, -7)
	return
}

// LoadWeeklyStats builds base per-user weekly stats WITHOUT direct acces to DB.
func LoadWeeklyStats(store *storage.Storage) ([]WeeklyUserStats, error) {
	from, to := lastWeekRange()

	voiceRows, err := store.LoadWeeklyVoiceRaw(from, to)
	if err != nil {
		return nil, err
	}

	gameRows, err := store.LoadWeeklyGameRaw(from, to)
	if err != nil {
		return nil, err
	}

	byUser := map[string]*WeeklyUserStats{}

	get := func(userID, username string) *WeeklyUserStats {
		st := byUser[userID]
		if st == nil {
			st = &WeeklyUserStats{UserID: userID}
			byUser[userID] = st
		}
		if st.Username == "" && username != "" {
			st.Username = username
		}
		return st
	}

	for _, r := range voiceRows {
		st := get(r.UserID, r.Username)
		st.VoiceSeconds = r.Seconds
	}

	// gameRows сгруппированы по (user_id, game)
	for _, r := range gameRows {
		st := get(r.UserID, r.Username)
		st.GameSeconds += r.Seconds
		st.DistinctGames++
		// GameSessionsCount сейчас не посчитать из этих raw-данных корректно — оставляем 0.
	}

	res := make([]WeeklyUserStats, 0, len(byUser))
	for _, st := range byUser {
		if st.Username == "" {
			st.Username = st.UserID
		}
		res = append(res, *st)
	}
	return res, nil
}

// LoadWeeklyAFK заполняет WeeklyUserStats.AFKSeconds (канал "Я_за_хлебушком_пацаны")
func LoadWeeklyAFK(store *storage.Storage, stats []WeeklyUserStats) error {
	from, to := lastWeekRange()

	rows, err := store.LoadWeeklyBreadAFKRaw(from, to, "Я_за_хлебушком_пацаны")
	if err != nil {
		return err
	}

	afkByUser := map[string]storage.WeeklyBreadAFKRow{}
	for _, r := range rows {
		afkByUser[r.UserID] = r
	}

	for i := range stats {
		if r, ok := afkByUser[stats[i].UserID]; ok {
			if stats[i].Username == "" {
				stats[i].Username = r.Username
			}
			stats[i].AFKSeconds = r.Seconds
		}
	}
	return nil
}

// LoadWeeklyMaxGame заполняет MaxSingleGame / MaxSingleGameSec
func LoadWeeklyMaxGame(store *storage.Storage, stats []WeeklyUserStats) error {
	from, to := lastWeekRange()

	rows, err := store.LoadWeeklyGameRaw(from, to)
	if err != nil {
		return err
	}

	maxByUser := map[string]struct {
		game string
		sec  int64
	}{}

	for _, r := range rows {
		cur, ok := maxByUser[r.UserID]
		if !ok || r.Seconds > cur.sec {
			maxByUser[r.UserID] = struct {
				game string
				sec  int64
			}{game: r.Game, sec: r.Seconds}
		}
	}

	for i := range stats {
		if m, ok := maxByUser[stats[i].UserID]; ok {
			stats[i].MaxSingleGame = m.game
			stats[i].MaxSingleGameSec = m.sec
		}
	}
	return nil
}
